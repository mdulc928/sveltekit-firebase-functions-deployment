import{b as a}from"../chunks/entry.0-3npzez.js";export{a as start};
