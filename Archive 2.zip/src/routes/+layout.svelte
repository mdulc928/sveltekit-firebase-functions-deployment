<script lang="ts">
	import '../app.css';
</script>

<a href="/mySecondPage" class="underline hover:cursor-pointer hover:text-blue-300">My second Page</a
>
<slot />
